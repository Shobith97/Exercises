/*
 *  UCF COP3330 Summer 2021 Assignment 1 Solution
 *  Copyright 2021 Shobith Bandaru
 */

public class Excercise1 {
    public static void main(String[] args) {
        System.out.println("What is your name? Shobith");
	System.out.println("Hello, Shobith, nice to meet you!");
    }
}